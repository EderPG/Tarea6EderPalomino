
function myFunction() {
    // Get the value of the input field with id="palabra"
    let x1 = document.getElementById("palabra").value;
    const regex = /^(p|s).+(o|a)$/i;
  
    if (regex.test(x1)) {
      text="Nombre valido";
    }
    else {
      text="Nombre no valido";
    }
    document.getElementById("valida_palabra").innerHTML = text;
  
    // Get the value of the input field with id="numero"
    let x2 = document.getElementById("numero").value;
    const regex2 = /^[0-9]{2}$/i;
  
    if (regex2.test(x2)) {
      text="Numero valido";
    }
    else {
      text="Numero no valido";
    }
  
    document.getElementById("valida_numero").innerHTML = text;
  
    // valida nombre
    let x3 = document.getElementById("nombre").value;
    const regex3 = /[A-Z a-z]*[a-z]*/i ;
    if (regex3.test(x3)){
        text="Nombre valido";
    }
    else{
        tex="Nombre no vallido";
    }
    document.getElementById("valida_nombre").innerHTML = text;

    //valida numero de control
    let x4 = document.getElementById("numcontrol").value;
    const regex4 = /^(m|c)?[0-9]{2}(120|121)[0-9]{3}$/i;

    if (regex4.test(x4)){
        text="Numero de control valido";
    }
    else{
        text="Numero de control no valido";
    }
    document.getElementById("valida_numcontrol").innerHTML = text;
    //valida numero de control

    //valida rfc
    let x5 = document.getElementById("rfc").value;
    const regex5 = /^[A-Z]{4}([0-9]{6})\w{3}$/i ;
    const FechaNac = regex5.exec(x5); 
    if (regex5.test(x5)){
        text="RFC valido";
        console.log("Fecha de nacimiento: "+FechaNac)
    }
    else{
        text="RFC no valido";
    }
    document.getElementById("valida_rfc").innerHTML = text;
    //valida rfc

    //validar numero telefonico (443)
    let x6 = document.getElementById("numtelefono").value;
    const regex6 = /^(443)[0-9]+$/ ;
    
    if (regex6.test(x6)){
        text="Numero telefonico valido";
    }
    else{
        text="Numero telefonico no valido";
    }
    document.getElementById("valida_numtelefono").innerHTML = text;
    //validar numero telefonico (443)

    //correo electronico
    let x7 = document.getElementById("correo").value;
  
  const regex7 = /^(l)((m|c)?[0-9]{2}(120|121)[0-9]{3})(@morelia.tecnm.mx)$/i;

  if (regex7.test(x7)) {
    const Correo = regex7.exec(x7); 
    console.log(""+Correo);
    console.log("Correo: "+Correo[2]);
    console.log("Número de control: "+valNC[0]);
    text ="Correo válido";


    if(Correo[2] == valNC[0]){
    text="Correo valido";
    text ="Correo válido";
    document.getElementById("valida_correo").innerHTML = text;
    
  
  }else{
      
      text ="Correo NO válido";
      document.getElementById("Correo_valido").innerHTML = text;
      text="El correo no coincide con el número de control";
    document.getElementById("valida_correo").innerHTML = text;
    }
    
  }
    //correo electronico


    const nombre = regex3.exec(x3);
    console.log("Nombre: "+nombre);
     const Concatenados = "Usuario verificado: "+nombre+" nacido el "+FechaNac[1];
     document.getElementById("datos").innerHTML = Concatenados;
  }
